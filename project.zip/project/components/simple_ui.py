SIMPLEUI_DEFAULT_THEME = 'Enterprise green'

SIMPLEUI_HOME_ACTION = True

SIMPLEUI_HOME_INFO = False

SIMPLEUI_HOME_QUICK = True

SIMPLEUI_INDEX = 'google.ru'

SIMPLEUI_LOADING = True

SIMPLEUI_LOGO = '/static/project/img/admin/logo.png'
