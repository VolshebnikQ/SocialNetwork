from django.contrib import admin

from .models import City, Message


admin.site.register(City)
admin.site.register(Message)
