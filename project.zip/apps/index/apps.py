from django.apps import AppConfig


class IndexConfig(AppConfig):
    name = 'apps.index'
    verbose_name = 'Социальная сеть'
