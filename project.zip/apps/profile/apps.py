from django.apps import AppConfig


class ProfilesConfig(AppConfig):
    name = 'apps.profile'
    verbose_name = "Учётные записи"
