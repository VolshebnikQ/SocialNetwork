from django.apps import AppConfig


class PublicationsConfig(AppConfig):
    name = 'apps.publications'
    verbose_name = "Публикации"
