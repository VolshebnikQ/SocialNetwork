default_app_config = 'apps.publications.apps.PublicationsConfig'
